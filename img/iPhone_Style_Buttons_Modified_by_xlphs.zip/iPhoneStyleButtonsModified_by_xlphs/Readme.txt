You may not use these buttons for commercial purpose.

You are free to do whatever you like with the psd file.

Buttons created by xlphs. iPhone inspired.